# Libstdc-.6.0.9-files
该项目用于Xcode 10+ 不支持使用lbstdc++插件报错异常解决方案

类似这种报错Info: `Error: ld: library not found for "-lstdc++.6"`

用法：
1.设备（真机）

将tbd副本放到下面路径中：

/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk/usr/lib/

2.模拟器

将tdb副本和dylib放到下面路径中：

/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/usr/lib/

## Download

也可以点击[这里](https://github.com/WJYJane/-Xcode10-)进行文件下载
